#include <stdio.h>
int main() {
printf("bonjour\n");
return 0;
}
