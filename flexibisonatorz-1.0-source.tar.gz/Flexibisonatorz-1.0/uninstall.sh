#!/bin/bash
sudo dpkg -r flexibisonatorz

